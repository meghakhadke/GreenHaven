import React from 'react';
import { Leaf, Shield, Sparkles, Droplets } from 'lucide-react';
import { motion } from 'framer-motion';
import PlantAccordion from './PlantAccordion';

const IndoorPlants = () => {
  const plants = [
    {
      name: "Snake Plant",
      image: "https://images.pexels.com/photos/4751978/pexels-photo-4751978.jpeg?auto=compress&cs=tinysrgb&w=400",
      benefits: ["Air Purifying", "Low Maintenance", "Night Oxygen Producer"],
      description: "Perfect for beginners, requires minimal care and thrives in low light.",
      detailedInfo: "Snake plants are incredibly resilient and can survive in low light conditions. They're known for producing oxygen at night, making them perfect for bedrooms. Water only when soil is completely dry."
    },
    {
      name: "Peace Lily", 
      image: "https://images.pexels.com/photos/4503624/pexels-photo-4503624.jpeg?auto=compress&cs=tinysrgb&w=400",
      benefits: ["Air Purifying", "Beautiful Blooms", "Humidity Loving"],
      description: "Elegant white flowers and glossy leaves make this a stunning centerpiece.",
      detailedInfo: "Peace lilies prefer bright, indirect light and consistently moist soil. They'll droop when thirsty, making it easy to know when to water. The white blooms can last for months with proper care."
    },
    {
      name: "Aloe Vera",
      image: "https://images.pexels.com/photos/4751978/pexels-photo-4751978.jpeg?auto=compress&cs=tinysrgb&w=400",
      benefits: ["Medicinal Properties", "Drought Tolerant", "Easy Care"],
      description: "Natural healing properties and requires very little water to thrive.",
      detailedInfo: "Aloe vera gel can be used to treat minor burns and skin irritations. This succulent prefers bright light and infrequent watering. Allow soil to dry completely between waterings."
    },
    {
      name: "Money Plant",
      image: "https://images.pexels.com/photos/6208086/pexels-photo-6208086.jpeg?auto=compress&cs=tinysrgb&w=400",
      benefits: ["Fast Growing", "Air Purifying", "Feng Shui Benefits"],
      description: "Brings good luck and prosperity while cleaning your indoor air.",
      detailedInfo: "Money plants are excellent climbers and can be trained on moss poles. They grow quickly in bright, indirect light and prefer to dry out slightly between waterings. Perfect for beginners."
    },
    {
      name: "ZZ Plant",
      image: "https://images.pexels.com/photos/4503624/pexels-photo-4503624.jpeg?auto=compress&cs=tinysrgb&w=400",
      benefits: ["Extremely Low Maintenance", "Glossy Leaves", "Drought Resistant"],
      description: "Nearly indestructible plant that thrives on neglect and low light.",
      detailedInfo: "ZZ plants can tolerate neglect better than most houseplants. They store water in their thick stems and can go weeks without watering. Perfect for offices and low-light areas."
    },
    {
      name: "Rubber Plant",
      image: "https://images.pexels.com/photos/6208086/pexels-photo-6208086.jpeg?auto=compress&cs=tinysrgb&w=400",
      benefits: ["Large Statement Leaves", "Air Purifying", "Fast Growing"],
      description: "Bold, glossy leaves create a dramatic focal point in any room.",
      detailedInfo: "Rubber plants can grow quite large indoors and make excellent floor plants. They prefer bright, indirect light and regular watering. Wipe leaves regularly to maintain their glossy appearance."
    }
  ];

  const getBenefitIcon = (benefit: string) => {
    if (benefit.includes('Air Purifying')) return <Shield className="h-4 w-4 text-green-600" />;
    if (benefit.includes('Low Maintenance')) return <Leaf className="h-4 w-4 text-green-600" />;
    if (benefit.includes('Beautiful') || benefit.includes('Aesthetic')) return <Sparkles className="h-4 w-4 text-green-600" />;
    return <Droplets className="h-4 w-4 text-green-600" />;
  };

  return (
    <section id="indoor-plants" className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div 
          className="text-center mb-16"
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          viewport={{ once: true }}
        >
          <motion.h2 
            className="text-4xl md:text-5xl font-bold text-green-800 mb-6"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2, duration: 0.6 }}
            viewport={{ once: true }}
          >
            Indoor Plants Collection
          </motion.h2>
          <motion.p 
            className="text-xl text-gray-600 max-w-3xl mx-auto"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.4, duration: 0.6 }}
            viewport={{ once: true }}
          >
            Transform your living space with our carefully selected indoor plants, 
            perfect for purifying air and adding natural beauty to your home.
          </motion.p>
        </motion.div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {plants.map((plant, index) => (
            <motion.div 
              key={index}
              className="bg-white rounded-2xl shadow-lg overflow-hidden hover:shadow-2xl transition-all duration-300 transform hover:-translate-y-2 group"
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.1, duration: 0.6 }}
              viewport={{ once: true }}
              whileHover={{ y: -8 }}
            >
              <div className="relative overflow-hidden">
                <img 
                  src={plant.image}
                  alt={plant.name}
                  className="w-full h-64 object-cover transition-transform duration-500 group-hover:scale-110"
                />
              </div>
              
              <div className="p-6">
                <h3 className="text-2xl font-bold text-green-800 mb-3">{plant.name}</h3>
                <p className="text-gray-600 mb-4">{plant.description}</p>
                
                <div className="space-y-2 mb-6">
                  {plant.benefits.map((benefit, idx) => (
                    <div key={idx} className="flex items-center gap-2">
                      {getBenefitIcon(benefit)}
                      <span className="text-sm text-gray-600">{benefit}</span>
                    </div>
                  ))}
                </div>
                
                <PlantAccordion title="See More Information">
                  <p className="text-gray-600 leading-relaxed">
                    {plant.detailedInfo}
                  </p>
                </PlantAccordion>
              </div>
            </motion.div>
          ))}
        </div>
        
        <motion.div 
          className="text-center mt-12"
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.6, duration: 0.6 }}
          viewport={{ once: true }}
        >
          <motion.button 
            onClick={() => scrollToSection('gallery')}
            className="bg-green-600 hover:bg-green-700 text-white px-8 py-4 rounded-full text-lg font-semibold transition-all duration-300"
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
          >
            View Indoor Gallery
          </motion.button>
        </motion.div>
      </div>
    </section>
  );
};

  const scrollToSection = (sectionId: string) => {
    const element = document.getElementById(sectionId);
    element?.scrollIntoView({ behavior: 'smooth' });
  };

export default IndoorPlants;