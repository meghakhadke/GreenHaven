import React from 'react';
import { Droplets, Sun, Shovel, Calendar, Palette, TreePine } from 'lucide-react';

const ExtraInfo = () => {
  const careItems = [
    {
      icon: <Droplets className="h-8 w-8 text-blue-600" />,
      title: "Watering Schedule",
      description: "Most houseplants prefer the 'soak and dry' method - water thoroughly when the top inch of soil is dry.",
      tips: ["Check soil moisture weekly", "Use room temperature water", "Avoid overwatering"]
    },
    {
      icon: <Sun className="h-8 w-8 text-yellow-600" />,
      title: "Light Requirements", 
      description: "Understanding your plant's light needs is crucial for healthy growth and vibrant foliage.",
      tips: ["Bright indirect light for most plants", "Rotate plants weekly", "Consider grow lights for dark areas"]
    },
    {
      icon: <Shovel className="h-8 w-8 text-amber-700" />,
      title: "Soil Types",
      description: "The right soil mix provides proper drainage while retaining necessary nutrients and moisture.",
      tips: ["Well-draining potting mix", "Add perlite for drainage", "Use specialized soil for specific plants"]
    }
  ];

  const seasonalPlants = [
    {
      season: "Spring",
      plants: ["Petunias", "Marigolds", "Tomato Seedlings", "Herb Garden Starters"],
      color: "green"
    },
    {
      season: "Summer", 
      plants: ["Sunflowers", "Zinnias", "Pepper Plants", "Heat-Tolerant Varieties"],
      color: "orange"
    },
    {
      season: "Fall",
      plants: ["Chrysanthemums", "Pansies", "Ornamental Kale", "Cool-Season Vegetables"],
      color: "amber"
    },
    {
      season: "Winter",
      plants: ["Poinsettias", "Christmas Cactus", "Amaryllis", "Indoor Herb Gardens"],
      color: "red"
    }
  ];

  const services = [
    {
      icon: <Palette className="h-8 w-8 text-purple-600" />,
      title: "Decorative Pots & Planters",
      description: "Stunning ceramic, terracotta, and modern planters to complement any decor style."
    },
    {
      icon: <TreePine className="h-8 w-8 text-green-600" />,
      title: "Landscaping Services", 
      description: "Professional design and installation services to transform your outdoor space."
    },
    {
      icon: <Calendar className="h-8 w-8 text-indigo-600" />,
      title: "Plant Care Consultations",
      description: "Expert advice on plant selection, care, and troubleshooting for your specific needs."
    }
  ];

  return (
    <section id="extra-info" className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Plant Care Tips */}
        <div className="mb-20">
          <div className="text-center mb-12">
            <h2 className="text-4xl font-bold text-green-800 mb-4">Plant Care Tips</h2>
            <p className="text-xl text-gray-600">Expert guidance to help your plants thrive</p>
          </div>
          
          <div className="grid md:grid-cols-3 gap-8">
            {careItems.map((item, index) => (
              <div key={index} className="bg-gray-50 rounded-xl p-8 hover:shadow-lg transition-shadow duration-300">
                <div className="flex items-center mb-4">
                  <div className="bg-white rounded-full p-3 shadow-md mr-4">
                    {item.icon}
                  </div>
                  <h3 className="text-xl font-bold text-gray-800">{item.title}</h3>
                </div>
                <p className="text-gray-600 mb-4">{item.description}</p>
                <ul className="space-y-2">
                  {item.tips.map((tip, idx) => (
                    <li key={idx} className="flex items-center text-sm text-gray-600">
                      <div className="w-2 h-2 bg-green-500 rounded-full mr-2"></div>
                      {tip}
                    </li>
                  ))}
                </ul>
              </div>
            ))}
          </div>
        </div>

        {/* Seasonal Recommendations */}
        <div className="mb-20">
          <div className="text-center mb-12">
            <h2 className="text-4xl font-bold text-green-800 mb-4">Seasonal Plant Recommendations</h2>
            <p className="text-xl text-gray-600">The perfect plants for every season</p>
          </div>
          
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            {seasonalPlants.map((season, index) => (
              <div key={index} className="bg-gradient-to-b from-white to-gray-50 rounded-xl p-6 border-2 border-gray-100 hover:border-green-300 transition-colors duration-300">
                <h3 className={`text-2xl font-bold text-${season.color}-600 mb-4`}>{season.season}</h3>
                <ul className="space-y-2">
                  {season.plants.map((plant, idx) => (
                    <li key={idx} className="flex items-center text-gray-700">
                      <div className={`w-2 h-2 bg-${season.color}-500 rounded-full mr-3`}></div>
                      {plant}
                    </li>
                  ))}
                </ul>
              </div>
            ))}
          </div>
        </div>

        {/* Additional Services */}
        <div>
          <div className="text-center mb-12">
            <h2 className="text-4xl font-bold text-green-800 mb-4">Additional Services</h2>
            <p className="text-xl text-gray-600">Complete solutions for all your gardening needs</p>
          </div>
          
          <div className="grid md:grid-cols-3 gap-8">
            {services.map((service, index) => (
              <div key={index} className="text-center p-8 bg-gray-50 rounded-xl hover:bg-white hover:shadow-lg transition-all duration-300">
                <div className="bg-white rounded-full p-4 shadow-md inline-block mb-4">
                  {service.icon}
                </div>
                <h3 className="text-xl font-bold text-gray-800 mb-3">{service.title}</h3>
                <p className="text-gray-600">{service.description}</p>
                <button className="mt-4 text-green-600 hover:text-green-700 font-semibold">
                  Learn More →
                </button>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};

export default ExtraInfo;