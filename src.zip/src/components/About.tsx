import React from 'react';
import { Award, Heart, Leaf } from 'lucide-react';
import { motion } from 'framer-motion';

const About = () => {
  return (
    <section id="about" className="py-20 bg-gradient-to-b from-green-50 to-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div 
          className="text-center mb-16"
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          viewport={{ once: true }}
        >
          <motion.h2 
            className="text-4xl md:text-5xl font-bold text-green-800 mb-6"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2, duration: 0.6 }}
            viewport={{ once: true }}
          >
            About GreenHaven Nursery
          </motion.h2>
          <motion.p 
            className="text-xl text-gray-600 max-w-3xl mx-auto"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.4, duration: 0.6 }}
            viewport={{ once: true }}
          >
            For over 25 years, we've been passionate about bringing the beauty of nature 
            to homes and gardens across the region.
          </motion.p>
        </motion.div>

        <motion.div 
          className="grid lg:grid-cols-2 gap-12 items-center mb-16"
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3, duration: 0.8 }}
          viewport={{ once: true }}
        >
          <motion.div 
            className="space-y-6"
            initial={{ opacity: 0, x: -30 }}
            whileInView={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.5, duration: 0.6 }}
            viewport={{ once: true }}
          >
            <h3 className="text-3xl font-bold text-green-700 mb-4">Our Story</h3>
            <p className="text-lg text-gray-600 leading-relaxed">
              Founded in 1998 by plant enthusiasts Maria and John Green, GreenHaven Nursery 
              started as a small family business with a simple mission: to share our love 
              for plants with our community. Today, we're proud to be one of the region's 
              most trusted sources for healthy, vibrant plants.
            </p>
            <p className="text-lg text-gray-600 leading-relaxed">
              Our commitment to sustainable growing practices and exceptional customer service 
              has helped thousands of customers create beautiful, thriving gardens and indoor 
              plant collections.
            </p>
          </motion.div>
          
          <motion.div 
            className="relative"
            initial={{ opacity: 0, x: 30 }}
            whileInView={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.7, duration: 0.6 }}
            viewport={{ once: true }}
          >
            <img 
              src="https://images.pexels.com/photos/1084199/pexels-photo-1084199.jpeg?auto=compress&cs=tinysrgb&w=600"
              alt="Our nursery greenhouse"
              className="w-full h-96 object-cover rounded-2xl shadow-2xl"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-black/20 to-transparent rounded-2xl"></div>
          </motion.div>
        </motion.div>

        <div className="grid md:grid-cols-3 gap-8">
          {[
            {
              icon: <Leaf className="h-8 w-8 text-green-600" />,
              title: "Sustainable Practices",
              description: "We use eco-friendly growing methods, organic fertilizers, and water-efficient irrigation systems to minimize our environmental impact."
            },
            {
              icon: <Award className="h-8 w-8 text-green-600" />,
              title: "Expert Knowledge", 
              description: "Our certified horticulturists provide expert advice on plant care, helping you choose the perfect plants for your space and lifestyle."
            },
            {
              icon: <Heart className="h-8 w-8 text-green-600" />,
              title: "Community First",
              description: "We're deeply rooted in our community, supporting local schools and organizations with educational programs about plant care and gardening."
            }
          ].map((item, index) => (
            <motion.div 
              key={index}
              className="text-center p-8 bg-white rounded-2xl shadow-lg hover:shadow-xl transition-shadow duration-300"
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.6 + index * 0.2, duration: 0.6 }}
              viewport={{ once: true }}
              whileHover={{ y: -5 }}
            >
            <div className="bg-green-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
              {item.icon}
            </div>
            <h4 className="text-xl font-bold text-green-800 mb-3">{item.title}</h4>
            <p className="text-gray-600">
              {item.description}
            </p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default About;