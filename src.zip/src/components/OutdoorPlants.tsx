import React from 'react';
import { Sun, TreePine, Flower2, Home } from 'lucide-react';
import { motion } from 'framer-motion';
import PlantAccordion from './PlantAccordion';

const OutdoorPlants = () => {
  const plants = [
    {
      name: "Hibiscus",
      image: "https://images.pexels.com/photos/158063/bellis-perennis-daisy-flower-spring-158063.jpeg?auto=compress&cs=tinysrgb&w=400",
      benefits: ["Vibrant Blooms", "Attracts Butterflies", "Heat Tolerant"],
      description: "Stunning tropical flowers that bloom throughout the growing season.",
      detailedInfo: "Hibiscus plants produce large, colorful flowers from spring through fall. They prefer full sun and regular watering. In colder climates, they can be grown in containers and brought indoors for winter."
    },
    {
      name: "Bougainvillea",
      image: "https://images.pexels.com/photos/1386604/pexels-photo-1386604.jpeg?auto=compress&cs=tinysrgb&w=400", 
      benefits: ["Colorful Bracts", "Drought Resistant", "Climbing Vine"],
      description: "Spectacular climbing plant with papery colorful bracts in various hues.",
      detailedInfo: "Bougainvillea is perfect for covering walls, fences, or trellises. The colorful bracts come in pink, purple, red, orange, and white. Once established, they're very drought tolerant and bloom best in full sun."
    },
    {
      name: "Mango Saplings",
      image: "https://images.pexels.com/photos/1105019/pexels-photo-1105019.jpeg?auto=compress&cs=tinysrgb&w=400",
      benefits: ["Fruit Production", "Shade Provider", "Long-lived Tree"],
      description: "Young mango trees that will provide delicious fruit and cooling shade.",
      detailedInfo: "Mango trees typically begin producing fruit 3-5 years after planting. They prefer warm climates and well-draining soil. A mature mango tree can provide shade and fruit for decades."
    },
    {
      name: "Rose Plants",
      image: "https://images.pexels.com/photos/56866/garden-rose-red-pink-56866.jpeg?auto=compress&cs=tinysrgb&w=400",
      benefits: ["Classic Beauty", "Fragrant Blooms", "Cut Flowers"],
      description: "Classic garden roses in various colors, perfect for garden beds and borders.",
      detailedInfo: "Our rose collection includes hybrid teas, floribundas, and climbing varieties. They prefer morning sun and good air circulation. Regular pruning and feeding will ensure abundant blooms throughout the season."
    },
    {
      name: "Jasmine Vine",
      image: "https://images.pexels.com/photos/1386604/pexels-photo-1386604.jpeg?auto=compress&cs=tinysrgb&w=400",
      benefits: ["Night Fragrance", "Fast Growing", "White Flowers"],
      description: "Intensely fragrant climbing vine with small white star-shaped flowers.",
      detailedInfo: "Jasmine vines are known for their intoxicating evening fragrance. They're fast-growing and perfect for covering pergolas, fences, or arbors. The flowers are often used in perfumes and teas."
    },
    {
      name: "Palm Trees",
      image: "https://images.pexels.com/photos/1105019/pexels-photo-1105019.jpeg?auto=compress&cs=tinysrgb&w=400",
      benefits: ["Tropical Look", "Low Maintenance", "Wind Resistant"],
      description: "Create a tropical paradise with these elegant and sturdy palm varieties.",
      detailedInfo: "Our palm collection includes varieties suitable for different climates. They're generally low-maintenance once established and add instant tropical appeal to any landscape. Most varieties are also wind-resistant."
    }
  ];

  const getBenefitIcon = (benefit: string) => {
    if (benefit.includes('Shade') || benefit.includes('Tree')) return <TreePine className="h-4 w-4 text-green-600" />;
    if (benefit.includes('Blooms') || benefit.includes('Flowers') || benefit.includes('Beauty')) return <Flower2 className="h-4 w-4 text-green-600" />;
    if (benefit.includes('Heat') || benefit.includes('Sun') || benefit.includes('Drought')) return <Sun className="h-4 w-4 text-green-600" />;
    return <Home className="h-4 w-4 text-green-600" />;
  };

  return (
    <section id="outdoor-plants" className="py-20 bg-gradient-to-b from-green-50 to-green-100">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div 
          className="text-center mb-16"
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          viewport={{ once: true }}
        >
          <motion.h2 
            className="text-4xl md:text-5xl font-bold text-green-800 mb-6"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2, duration: 0.6 }}
            viewport={{ once: true }}
          >
            Outdoor Plants & Trees
          </motion.h2>
          <motion.p 
            className="text-xl text-gray-600 max-w-3xl mx-auto"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.4, duration: 0.6 }}
            viewport={{ once: true }}
          >
            Create stunning landscapes and gardens with our robust outdoor plants, 
            perfect for adding color, shade, and natural beauty to your outdoor spaces.
          </motion.p>
        </motion.div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {plants.map((plant, index) => (
            <motion.div 
              key={index}
              className="bg-white rounded-2xl shadow-lg overflow-hidden hover:shadow-2xl transition-all duration-300 transform hover:-translate-y-2 group"
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.1, duration: 0.6 }}
              viewport={{ once: true }}
              whileHover={{ y: -8 }}
            >
              <div className="relative overflow-hidden">
                <img 
                  src={plant.image}
                  alt={plant.name}
                  className="w-full h-64 object-cover transition-transform duration-500 group-hover:scale-110"
                />
              </div>
              
              <div className="p-6">
                <h3 className="text-2xl font-bold text-green-800 mb-3">{plant.name}</h3>
                <p className="text-gray-600 mb-4">{plant.description}</p>
                
                <div className="space-y-2 mb-6">
                  {plant.benefits.map((benefit, idx) => (
                    <div key={idx} className="flex items-center gap-2">
                      {getBenefitIcon(benefit)}
                      <span className="text-sm text-gray-600">{benefit}</span>
                    </div>
                  ))}
                </div>
                
                <PlantAccordion title="See More Information">
                  <p className="text-gray-600 leading-relaxed">
                    {plant.detailedInfo}
                  </p>
                </PlantAccordion>
              </div>
            </motion.div>
          ))}
        </div>
        
        <motion.div 
          className="text-center mt-12"
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.6, duration: 0.6 }}
          viewport={{ once: true }}
        >
          <motion.button 
            onClick={() => scrollToSection('gallery')}
            className="bg-orange-600 hover:bg-orange-700 text-white px-8 py-4 rounded-full text-lg font-semibold transition-all duration-300"
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
          >
            View Outdoor Gallery
          </motion.button>
        </motion.div>
      </div>
    </section>
  );
};

  const scrollToSection = (sectionId: string) => {
    const element = document.getElementById(sectionId);
    element?.scrollIntoView({ behavior: 'smooth' });
  };

export default OutdoorPlants;