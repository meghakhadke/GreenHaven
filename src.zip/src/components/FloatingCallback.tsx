import React, { useState } from 'react';
import { Phone } from 'lucide-react';
import { motion } from 'framer-motion';
import ContactModal from './ContactModal';

const FloatingCallback = () => {
  const [isModalOpen, setIsModalOpen] = useState(false);

  const openModal = () => {
    setIsModalOpen(true);
  };

  return (
    <>
      <motion.div
        className="fixed bottom-6 right-6 z-40"
        initial={{ scale: 0, rotate: -180 }}
        animate={{ scale: 1, rotate: 0 }}
        transition={{ delay: 1.5, type: "spring", stiffness: 200 }}
      >
        <motion.button
          onClick={openModal}
          className="bg-orange-600 hover:bg-orange-700 text-white rounded-full shadow-2xl transition-all duration-300 flex items-center gap-3 px-6 py-4"
          whileHover={{ scale: 1.05 }}
          whileTap={{ scale: 0.95 }}
        >
          <Phone className="h-5 w-5 animate-pulse" />
          <span className="font-semibold hidden sm:block">Request a Callback</span>
        </motion.button>
        
        {/* Pulse animation */}
        <motion.div
          className="absolute inset-0 bg-orange-600 rounded-full"
          animate={{
            scale: [1, 1.2, 1],
            opacity: [0.7, 0, 0.7]
          }}
          transition={{
            duration: 2,
            repeat: Infinity,
            ease: "easeInOut"
          }}
        />
      </motion.div>
      
      <ContactModal isOpen={isModalOpen} onClose={() => setIsModalOpen(false)} />
    </>
  );
};

export default FloatingCallback;