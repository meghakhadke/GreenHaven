import React from 'react';
import { Leaf, Facebook, Instagram, MessageSquare, Mail, Phone, MapPin } from 'lucide-react';

const Footer = () => {
  const scrollToSection = (sectionId: string) => {
    const element = document.getElementById(sectionId);
    element?.scrollIntoView({ behavior: 'smooth' });
  };

  return (
    <footer className="bg-green-800 text-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="grid lg:grid-cols-4 md:grid-cols-2 gap-8">
          {/* Brand Section */}
          <div className="space-y-4">
            <div className="flex items-center gap-3">
              <Leaf className="h-8 w-8 text-green-400" />
              <h3 className="text-2xl font-bold">GreenHaven</h3>
            </div>
            <p className="text-green-100 leading-relaxed">
              Bringing nature closer to you since 1998. Your trusted partner 
              for all gardening and plant care needs.
            </p>
            <div className="flex space-x-4">
              <a 
                href="https://facebook.com" 
                target="_blank" 
                rel="noopener noreferrer"
                className="bg-green-700 hover:bg-green-600 p-2 rounded-full transition-colors duration-300"
              >
                <Facebook className="h-5 w-5" />
              </a>
              <a 
                href="https://instagram.com" 
                target="_blank" 
                rel="noopener noreferrer"
                className="bg-green-700 hover:bg-green-600 p-2 rounded-full transition-colors duration-300"
              >
                <Instagram className="h-5 w-5" />
              </a>
              <a 
                href="https://wa.me/1234567890" 
                target="_blank" 
                rel="noopener noreferrer"
                className="bg-green-700 hover:bg-green-600 p-2 rounded-full transition-colors duration-300"
              >
                <MessageSquare className="h-5 w-5" />
              </a>
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h4 className="text-lg font-semibold mb-6 text-green-300">Quick Links</h4>
            <ul className="space-y-3">
              <li>
                <button 
                  onClick={() => scrollToSection('hero')}
                  className="text-green-100 hover:text-white transition-colors duration-300"
                >
                  Home
                </button>
              </li>
              <li>
                <button 
                  onClick={() => scrollToSection('about')}
                  className="text-green-100 hover:text-white transition-colors duration-300"
                >
                  About
                </button>
              </li>
              <li>
                <button 
                  onClick={() => scrollToSection('indoor-plants')}
                  className="text-green-100 hover:text-white transition-colors duration-300"
                >
                  Indoor Plants
                </button>
              </li>
              <li>
                <button 
                  onClick={() => scrollToSection('outdoor-plants')}
                  className="text-green-100 hover:text-white transition-colors duration-300"
                >
                  Outdoor Plants
                </button>
              </li>
              <li>
                <button 
                  onClick={() => scrollToSection('gallery')}
                  className="text-green-100 hover:text-white transition-colors duration-300"
                >
                  Gallery
                </button>
              </li>
              <li>
                <button 
                  onClick={() => scrollToSection('contact')}
                  className="text-green-100 hover:text-white transition-colors duration-300"
                >
                  Contact
                </button>
              </li>
            </ul>
          </div>

          {/* Services */}
          <div>
            <h4 className="text-lg font-semibold mb-6 text-green-300">Our Services</h4>
            <ul className="space-y-3 text-green-100">
              <li>Plant Sales & Consultation</li>
              <li>Landscaping Design</li>
              <li>Garden Maintenance</li>
              <li>Plant Care Workshops</li>
              <li>Soil Testing & Analysis</li>
              <li>Custom Planters & Pots</li>
            </ul>
          </div>

          {/* Contact Info */}
          <div>
            <h4 className="text-lg font-semibold mb-6 text-green-300">Contact Info</h4>
            <div className="space-y-4 text-green-100">
              <div className="flex items-start gap-3">
                <MapPin className="h-5 w-5 text-green-400 mt-1" />
                <div>
                  <p>123 Garden Lane</p>
                  <p>Green Valley, BC 12345</p>
                </div>
              </div>
              <div className="flex items-center gap-3">
                <Phone className="h-5 w-5 text-green-400" />
                <p>+1 (555) 123-4567</p>
              </div>
              <div className="flex items-center gap-3">
                <Mail className="h-5 w-5 text-green-400" />
                <p>info@greenhavennursery.com</p>
              </div>
            </div>
          </div>
        </div>

        {/* Bottom Section */}
        <div className="border-t border-green-700 mt-12 pt-8 text-center">
          <p className="text-green-200">
            © 2024 GreenHaven Nursery. All rights reserved. | 
            <span className="ml-2">Made with 🌱 for plant lovers</span>
          </p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;