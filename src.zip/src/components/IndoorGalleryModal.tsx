import React, { useState } from 'react';
import { X, ChevronLeft, ChevronRight } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';

interface IndoorGalleryModalProps {
  isOpen: boolean;
  onClose: () => void;
}

const IndoorGalleryModal: React.FC<IndoorGalleryModalProps> = ({ isOpen, onClose }) => {
  const [currentImage, setCurrentImage] = useState(0);

  const indoorPlantImages = [
    {
      src: "https://images.pexels.com/photos/4751978/pexels-photo-4751978.jpeg?auto=compress&cs=tinysrgb&w=800",
      alt: "Snake Plant in modern pot",
      title: "Snake Plant Collection"
    },
    {
      src: "https://images.pexels.com/photos/4503624/pexels-photo-4503624.jpeg?auto=compress&cs=tinysrgb&w=800",
      alt: "Peace Lily with white blooms",
      title: "Peace Lily Varieties"
    },
    {
      src: "https://images.pexels.com/photos/6208086/pexels-photo-6208086.jpeg?auto=compress&cs=tinysrgb&w=800",
      alt: "Money Plant in hanging basket",
      title: "Money Plant Display"
    },
    {
      src: "https://images.pexels.com/photos/1084199/pexels-photo-1084199.jpeg?auto=compress&cs=tinysrgb&w=800",
      alt: "Indoor plant corner setup",
      title: "Indoor Plant Corner"
    },
    {
      src: "https://images.pexels.com/photos/1072824/pexels-photo-1072824.jpeg?auto=compress&cs=tinysrgb&w=800",
      alt: "Aloe Vera collection",
      title: "Aloe Vera Garden"
    },
    {
      src: "https://images.pexels.com/photos/4751978/pexels-photo-4751978.jpeg?auto=compress&cs=tinysrgb&w=800",
      alt: "ZZ Plant in decorative pot",
      title: "ZZ Plant Showcase"
    },
    {
      src: "https://images.pexels.com/photos/4503624/pexels-photo-4503624.jpeg?auto=compress&cs=tinysrgb&w=800",
      alt: "Rubber Plant in living room",
      title: "Rubber Plant Display"
    },
    {
      src: "https://images.pexels.com/photos/6208086/pexels-photo-6208086.jpeg?auto=compress&cs=tinysrgb&w=800",
      alt: "Indoor herb garden",
      title: "Indoor Herb Collection"
    }
  ];

  const nextImage = () => {
    setCurrentImage((prev) => (prev + 1) % indoorPlantImages.length);
  };

  const prevImage = () => {
    setCurrentImage((prev) => (prev - 1 + indoorPlantImages.length) % indoorPlantImages.length);
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 bg-black bg-opacity-90 z-50 flex items-center justify-center p-4"
          onClick={onClose}
        >
          <motion.div
            initial={{ scale: 0.9, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            exit={{ scale: 0.9, opacity: 0 }}
            className="relative max-w-4xl w-full"
            onClick={(e) => e.stopPropagation()}
          >
            {/* Header */}
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-2xl font-bold text-white">Indoor Plants Gallery</h2>
              <button
                onClick={onClose}
                className="text-white hover:text-gray-300 transition-colors"
              >
                <X className="h-8 w-8" />
              </button>
            </div>

            {/* Main Image */}
            <div className="relative bg-white rounded-lg overflow-hidden">
              <img
                src={indoorPlantImages[currentImage].src}
                alt={indoorPlantImages[currentImage].alt}
                className="w-full h-96 object-cover"
              />
              
              {/* Navigation Buttons */}
              <button
                onClick={prevImage}
                className="absolute left-4 top-1/2 transform -translate-y-1/2 bg-black bg-opacity-50 hover:bg-opacity-70 text-white p-2 rounded-full transition-all"
              >
                <ChevronLeft className="h-6 w-6" />
              </button>
              
              <button
                onClick={nextImage}
                className="absolute right-4 top-1/2 transform -translate-y-1/2 bg-black bg-opacity-50 hover:bg-opacity-70 text-white p-2 rounded-full transition-all"
              >
                <ChevronRight className="h-6 w-6" />
              </button>

              {/* Image Info */}
              <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black to-transparent p-4">
                <h3 className="text-white font-semibold text-lg">
                  {indoorPlantImages[currentImage].title}
                </h3>
                <p className="text-gray-300 text-sm">
                  {currentImage + 1} of {indoorPlantImages.length}
                </p>
              </div>
            </div>

            {/* Thumbnail Grid */}
            <div className="grid grid-cols-4 md:grid-cols-8 gap-2 mt-4">
              {indoorPlantImages.map((image, index) => (
                <motion.button
                  key={index}
                  onClick={() => setCurrentImage(index)}
                  className={`relative overflow-hidden rounded-lg ${
                    currentImage === index ? 'ring-2 ring-green-500' : ''
                  }`}
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                >
                  <img
                    src={image.src}
                    alt={image.alt}
                    className="w-full h-16 object-cover"
                  />
                  {currentImage === index && (
                    <div className="absolute inset-0 bg-green-500 bg-opacity-20" />
                  )}
                </motion.button>
              ))}
            </div>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
};

export default IndoorGalleryModal;