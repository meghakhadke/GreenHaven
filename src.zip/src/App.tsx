import React from 'react';
import Navbar from './components/Navbar';
import Hero from './components/Hero';
import About from './components/About';
import IndoorPlants from './components/IndoorPlants';
import OutdoorPlants from './components/OutdoorPlants';
import ExtraInfo from './components/ExtraInfo';
import Gallery from './components/Gallery';
import Contact from './components/Contact';
import Footer from './components/Footer';
import WhatsAppFloat from './components/WhatsAppFloat';
import FloatingCallback from './components/FloatingCallback';

function App() {
  return (
    <div className="min-h-screen">
      <Navbar />
      <Hero />
      <About />
      <IndoorPlants />
      <OutdoorPlants />
      <ExtraInfo />
      <Gallery />
      <Contact />
      <Footer />
      <WhatsAppFloat />
      <FloatingCallback />
    </div>
  );
}

export default App;